<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1 maximum-scale=1.0, user-scalable=no" />

    <!-- bootstrap cdn start  -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" />
    <!-- bootstrap cdn end  -->
    <!-- animation AOS start -->
    <link rel="stylesheet" href="css/aos.css" />
    <!-- animation AOS start -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/stepper.css" />


    <link rel="stylesheet" href="build/css/intlTelInput.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
    .iti-flag {
        background-image: url("teleJs/flags.png");
    }

    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
        .iti-flag {
            background-image: url("teleJs/flags@2x.png");
        }
    }
    </style>

    <title>Imdady - Pricing</title>
</head>

<body class="overflowhidderAOS">
    <!-- Navebar start  -->
    <?php include('header.php') ?>

    <div class="brder"></div>

    <!-- Navbar end  -->

    <div class="my-5 ">
        <div class="row">
            <div class="col-md-12 col-md-offset-3">
                <form id="form">
                    <ul id="progressbar">
                        <li class="active">Customer Details</li>
                        <li class="">Brand Details</li>
                        <li class="">Trial Created</li>
                    </ul>
                </form>
            </div>
        </div>
    </div>

    <div class="container">
        <!--Section: Contact v.2-->

        <section class="my-4">
            <form id="contact-form" name="contact-form" action="brand-details.php" method="POST">
                <div class="row">
                    <!--Grid column-->
                    <div class="col-md-6 col-12 mb-md-0 mb-5">

                        <!--Grid row-->
                        <div class="row">
                            <div class="col-md-12 py-1">
                                <div class="md-form mb-0">
                                    <input type="text" id="name" name="f_name" class="form-control" value=""
                                        placeholder="First Name" required />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 py-1">
                                <div class="md-form mb-0">
                                    <input type="text" id="name" name="l_name" class="form-control"
                                        placeholder="Last Name" required />
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 py-1">
                                <div class="md-form mb-0">
                                    <input type="email" id="name" name="email" class="form-control" placeholder="Email "
                                        required />
                                </div>
                            </div>
                        </div>




                        <div class="row">
                            <div class="col-md-6 align-self-center my-1 ">
                                <div class="form-group d-flex  align-items-center ">
                                    <select class="form-control country" id="list" onchange="getSelectValue();"
                                        required>
                                        <option selected>Custom select menu</option>
                                        <option>Easy Go</option>
                                        <option>Plug n Play</option>
                                        <option>Advance Setup</option>
                                        <option>Imdady R3 - RMS </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3 d-flex  align-items-center ">
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" id="customRadioInline1" onchange=" getSelectValue() " required
                                        name="customRadioInline1" value="month" class="custom-control-input" checked>
                                    <label class="custom-control-label" for="customRadioInline1">Month</label>
                                </div>
                            </div>
                            <div class="col-md-3 d-flex  align-items-center ">
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" id="customRadioInline2" onchange=" getSelectValue() " required
                                        name="customRadioInline1" value="year" class="custom-control-input">
                                    <label class="custom-control-label" for="customRadioInline2">Year</label>
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-md-6 col-6 py-1">
                                <div class="form-group">
                                    <input id="phone" maxlength="13" minlength="10" name="phone" type="tel"
                                        class="form-control" placeholder="Phone *" required />
                                </div>
                            </div>
                            <div class="col-md-6 col-6 py-1">
                                <div class="md-form mb-0">
                                    <input type="text" id="name" name="name" class="form-control" placeholder="State *"
                                        required />
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 py-1">
                                <div class="md-form mb-0">
                                    <input type="text" id="name" name="name" class="form-control" placeholder="City *"
                                        required />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 py-1">
                                <div class="md-form mb-0">
                                    <input type="text" id="name" name="name" class="form-control"
                                        placeholder="Street Address *" required />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 py-1">
                                <div class="md-form mb-0">
                                    <input type="text" id="name" name="name" class="form-control"
                                        placeholder="Zip Code *" required />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 py-1">
                                <div class="md-form mb-0 d-flex justify-content-center">
                                    <div class="g-recaptcha" data-sitekey="6LcTDdEcAAAAAD_EB1kbXA-97A9xWsShntEhJ_oZ">
                                    </div>

                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="col-md-6 col-12 mb-md-0 mb-5">
                        <div class="card mt-4">
                            <div class="card-body">
                                <h5 class="mb-3 allheadingSizes">ORDER SUMMARY</h5>

                                <ul class="list-group list-group-flush">
                                    <li class="
                      list-group-item
                      d-flex
                      justify-content-between
                      align-items-center
                      border-0
                      px-0
                      pb-0
                      font-weight-bold
                      allheadingSizes
                    ">
                                        Subtotal

                                        <span id="subTotal"> 2000.0$ </span>
                                    </li>

                                    <li class="
                      list-group-item
                      d-flex
                      justify-content-between
                      align-items-center
                      px-0
                      font-weight-bold
                      allheadingSizes
                    ">
                                        15% VAT

                                        <span style="color: blue; font-weight: bold" id="vat">25400.0$</span>
                                    </li>

                                    <li class="
                      list-group-item
                      d-flex
                      justify-content-between
                      align-items-center
                      px-0
                      font-weight-bold
                      allheadingSizes
                    ">
                                        Promotion

                                        <span style="color: blue; font-weight: bold">000.0 sar</span>
                                    </li>

                                    <li class="
                      list-group-item
                      d-flex
                      justify-content-between
                      align-items-center
                      px-0
                      font-weight-bold
                      allheadingSizes
                    ">
                                        Grand total
                                        <span style="color: blue; font-weight: bold">
                                            <a href="#" id="gTotal"> </a>
                                        </span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!--Grid column-->
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="d-flex justify-content-end mt-lg-4">

                            <button type="submit" class="text-capitalize bgBtn" data-aos="zoom-in-up"
                                data-aos-duration="1000">
                                Next
                            </button>

                        </div>
                    </div>
                </div>
            </form>
        </section>
        <!--Section: Contact v.2-->
    </div>

    <!-- footer start  -->
    <?php include('footer.php') ?>


    <!-- footer end  -->
    <script>
    let month = document.getElementById('customRadioInline1');
    let year = document.getElementById('customRadioInline2');

    // alert(year)
    function getSelectValue() {
        var selectedValue = document.getElementById("list").value;
        // alert(selectedValue);
        if (selectedValue == "Plug n Play" && month.checked) {

            let number = 190;
            var percentToGet = 15;
            var percent = (percentToGet / 100) * number;
            let totals = document.getElementById('gTotal');
            totals.innerHTML = `${number} sar`;

            let vat = document.getElementById('vat').innerHTML = `${percent} sar`;
            let subtotal = document.getElementById("subTotal").innerHTML = `${number -28.5} sar`;





        } else if (selectedValue == "Plug n Play" && year.checked) {

            let number = 1900;

            var percentToGet = 15;

            var percent = (percentToGet / 100) * number;
            let totals = document.getElementById('gTotal');
            totals.innerHTML = `${number} sar`;

            let vat = document.getElementById('vat').innerHTML = `${percent} sar`;
            let subtotal = document.getElementById("subTotal").innerHTML = `${number-285} sar`;


        } else if (selectedValue == "Advance Setup" && month.checked) {

            let number = 240;

            var percentToGet = 15;

            var percent = (percentToGet / 100) * number;
            let totals = document.getElementById('gTotal');
            totals.innerHTML = `${number} sar`;

            let vat = document.getElementById('vat').innerHTML = `${percent} sar`;
            let subtotal = document.getElementById("subTotal").innerHTML = `${number-36} sar`;


        } else if (selectedValue == "Advance Setup" && year.checked) {

            let number = 2400;

            var percentToGet = 15;

            var percent = (percentToGet / 100) * number;
            let totals = document.getElementById('gTotal');
            totals.innerHTML = `${number} sar`;

            let vat = document.getElementById('vat').innerHTML = `${percent} sar`;
            let subtotal = document.getElementById("subTotal").innerHTML = `${number -360} sar`;


        } else if (selectedValue == "Easy Go" && month.checked) {

            let number = 120;

            var percentToGet = 15;

            var percent = (percentToGet / 100) * number;
            let totals = document.getElementById('gTotal');
            totals.innerHTML = `${number} sar`;

            let vat = document.getElementById('vat').innerHTML = `${percent} sar`;
            let subtotal = document.getElementById("subTotal").innerHTML = `${number-18} sar`;


        } else if (selectedValue == "Easy Go" && year.checked) {

            let number = 1190;

            var percentToGet = 15;

            var percent = (percentToGet / 100) * number;
            let totals = document.getElementById('gTotal');
            totals.innerHTML = `${number} sar`;

            let vat = document.getElementById('vat').innerHTML = `${percent} sar`;
            let subtotal = document.getElementById("subTotal").innerHTML = `${number-178.5} sar`;


        } else if (selectedValue == "Imdady R3 - RMS" && month.checked) {

            let number = 200;

            var percentToGet = 15;

            var percent = (percentToGet / 100) * number;
            let totals = document.getElementById('gTotal');
            totals.innerHTML = `${number} sar`;

            let vat = document.getElementById('vat').innerHTML = `${percent} sar`;
            let subtotal = document.getElementById("subTotal").innerHTML = `${number-29} sar`;


        } else if (selectedValue == "Imdady R3 - RMS" && year.checked) {

            let number = 1900;

            var percentToGet = 15;

            var percent = (percentToGet / 100) * number;
            let totals = document.getElementById('gTotal');
            totals.innerHTML = `${number} sar`;

            let vat = document.getElementById('vat').innerHTML = `${percent} sar`;
            let subtotal = document.getElementById("subTotal").innerHTML = `${number-285} sar`;


        } else {

            let number = 120;

            var percentToGet = 15;

            var percent = (percentToGet / 100) * number;
            let totals = document.getElementById('gTotal');
            totals.innerHTML = `${number} sar`;

            let vat = document.getElementById('vat').innerHTML = `${percent} sar`;
            let subtotal = document.getElementById("subTotal").innerHTML = `${number} sar`;
        }
    }
    getSelectValue();
    </script>








    <!-- data AOS Animation start  -->
    <script src="js/AOS.js"></script>
    <script>
    AOS.init();
    </script>
    <!-- data AOS Animation start  -->

    <!-- tele lib  -->
    <script src="build/js/intlTelInput.js"></script>
    <script>
    var input = document.querySelector("#phone");
    window.intlTelInput(input, {
        // allowDropdown: false,
        // autoHideDialCode: false,
        // autoPlaceholder: "off",
        // dropdownContainer: document.body,
        // excludeCountries: ["us"],
        // formatOnDisplay: false,
        // geoIpLookup: function(callback) {
        //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
        //     var countryCode = (resp && resp.country) ? resp.country : "";
        //     callback(countryCode);
        //   });
        // },
        // hiddenInput: "full_number",
        initialCountry: "id",
        // localizedCountries: { 'de': 'Deutschland' },
        nationalMode: true,
        // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
        // placeholderNumberType: "MOBILE",
        // preferredCountries: ['cn', 'jp'],
        separateDialCode: true,
        utilsScript: "build/js/utils.js",
    });
    </script>
    <!-- tele lib  -->






    <!-- bootstrap cdn start  -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- bootstrap cdn end  -->
</body>

</html>