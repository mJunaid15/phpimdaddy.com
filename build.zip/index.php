<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1 maximum-scale=1.0, user-scalable=no" />
  
  <!-- bootstrap cdn start  -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" />
  <!-- bootstrap cdn end  -->
  <!-- animation AOS start -->
  <link rel="stylesheet" href="css/aos.css" />
  <!-- animation AOS start -->
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
  />




  <link rel="stylesheet" href="css/style.css" />
  <title>Imdady.com</title>
</head>

<body class="overflowhidderAOS">

  <!-- Navebar start  -->
  <?php include('header.php') ?>

  <div class="brder ">

  </div>


  <!-- Navbar end  -->

  <!-- banner section start  -->


  <div class="w-100 bg ">
    <!-- left bend  -->
    <div class="leftband">

      <img src="img/Left Band 1.png" alt="" class="img-fluid" data-aos="fade-down-left" data-aos-duration="1500">

      <br>

      <img src="img/Left Band 2.png" alt="" class="img-fluid" data-aos="fade-down-left" data-aos-duration="2200">

    </div>
    <!-- left bend end  -->
    <!-- right bend start  -->

    <div class="rightBand">
      <img src="img/Right Band 2.png" class="img-fluid"   data-aos="zoom-in" data-aos-duration="1200">
      


    </div>

    <div class="cirler ">
      <img src="img/Turquoise Circle.png" class="img-fluid"  data-aos="zoom-in-up" data-aos-duration="2200">

    </div>

    <!-- right bend start  -->






    <div class=" minWidth  ml-auto" style="width: 90%;" >
      <div class=" d-flex flex-md-row flex-sm-column justify-content-md-between  test bg-alignment">
        <div class="   mt-3   ">
          <h1 class="bgHeading" data-aos="fade-up" data-aos-duration="1000">Imdady <br> Your Innovation Partner</h1>
          <div class="ml-auto">
            <input type="text" class="bgInput text-capitalize text-left" placeholder="email address"
              data-aos="zoom-in-right" data-aos-duration="1000">

            <button class="text-capitalize bgBtn ml-3 " data-aos="zoom-in-up" data-aos-duration="1000">get demo</button>

          </div>
        </div>
        <div class="  p-0   d-flex justify-content-end ">
          <img src="img/laptop.png" alt="" class="img-fluid bglaptop" data-aos="fade-left" data-aos-duration="1000">

        </div>
      </div>

     
    </div>
  </div>



  <!-- banner section end  -->

  <!-- tags section start -->
  <div class="brder">

  </div>
  <div class="container-fluid my-5">

    <div class="container text-center  ">
      <div class="row animate__animated animate__backInLeft" >
        <div class="col-md-2 col-lg-2 col-sm-4 col-4 mt-2">
          <a href="" class="text-decoration-none ">
            <img src="img/Airbnb Logo.png" class="img-fluid ">
          </a>

        </div>
        <div class="col-md-2 col-lg-2 col-sm-4 col-4 mt-2">
          <a href="" class="text-decoration-none ">
            <img src="img/Hubspot Logo.png" class="img-fluid">
          </a>

        </div>
        <div class="col-md-2 col-lg-2 col-sm-4 col-4 mt-2">
          <a href="" class="text-decoration-none ">
            <img src="img/Google Logo.png" class="img-fluid">
          </a>

        </div>
        <div class="col-md-2 col-lg-2 col-sm-4 col-4 mt-2">
          <a href="" class="text-decoration-none ">
            <img src="img/Microsoft Logo.png" class="img-fluid">
          </a>

        </div>
        <div class="col-md-2 col-lg-2 col-sm-4 col-4 mt-2">
          <a href="" class="text-decoration-none ">
            <img src="img/Walmart Logo.png" class="img-fluid">
          </a>

        </div>
        <div class="col-md-2 col-lg-2 col-sm-4 col-4 mt-2">

          <a href="" class="text-decoration-none ">
            <img src="img/g15.png" class="img-fluid">
          </a>

        </div>
      </div>











    </div>

  </div>
  <!-- tags section end -->

  <!-- heading section start -->


  <div class="container-fluid my-4 noneAOS " >

    <h1 class="headchoose ">Let Imdady manage your business with Nextgen products.</h1>
    <p class="headchoosePara">We strive to provide value and solve company problems by providing advanced IT services and solutions.</p>
    
  </div>

  <div class="container my-4">
    <div class="row">
      <div class="col-md-4 col-lg-4 col-sm-4 col-4 text-center ">
        <img src="img/01.png" class="img-fluid" data-toggle="collapse" href="#collapseExample1" role="button"
          aria-expanded="false" aria-controls="collapseExample">
        <h1 class="infoHeading" data-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false"
          aria-controls="collapseExample">Imdady POS</h1>
        <p class="infoPara collapse d-md-none" id="collapseExample1">Analyze your orders, warehouse inventory, customers, and sales using one of the most advanced and user-friendly POS systems available. Its cloud service allows you to keep track of your sales from anywhere. All of the tools you’ll need to run your business are included.</p>
        <p class="infoPara  d-none d-md-block d-lg-block d-xl-block">Analyze your orders, warehouse inventory, customers, and sales using one of the most advanced and user-friendly POS systems available. Its cloud service allows you to keep track of your sales from anywhere. All of the tools you’ll need to run your business are included.</p>
      </div>
      <div class="col-md-4 col-lg-4 col-sm-4 col-4 text-center ">
        <img src="img/02.png" class="img-fluid" data-toggle="collapse" href="#collapseExample2" role="button"
          aria-expanded="false" aria-controls="collapseExample">
        <h1 class="infoHeading" data-toggle="collapse" href="#collapseExample2" role="button" aria-expanded="false"
          aria-controls="collapseExample">Imdady RMS</h1>
        <p class="infoPara collapse d-md-none" id="collapseExample2">RMS provides innovations and benefits to restaurants through a cloud-based system that includes strong and user-friendly capabilities that transform restaurant operations in ways that have never been seen before.</p>
        <p class="infoPara  d-none d-md-block d-lg-block d-xl-block">RMS provides innovations and benefits to restaurants through a cloud-based system that includes strong and user-friendly capabilities that transform restaurant operations in ways that have never been seen before.</p>
      </div>
      <div class="col-md-4 col-lg-4 col-sm-4 col-4 text-center ">
        <img src="img/Group.png" class="img-fluid" data-toggle="collapse" href="#collapseExample3" role="button"
          aria-expanded="false" aria-controls="collapseExample">
        <h1 class="infoHeading" data-toggle="collapse" href="#collapseExample3" role="button" aria-expanded="false"
          aria-controls="collapseExample">Ecommerce Solution</h1>
        <p class="infoPara collapse d-md-none" id="collapseExample3">Taswog is an online e-commerce store with a multivendor system that focuses on assisting both consumers and sellers. The seller will be able to manage all of their inventory with the help of our application, which includes a sales forecasting system.</p>
        <p class="infoPara  d-none d-md-block d-lg-block d-xl-block">Taswog is an online e-commerce store with a multivendor system that focuses on assisting both consumers and sellers. The seller will be able to manage all of their inventory with the help of our application, which includes a sales forecasting system.</p>
      </div>

    </div>

  </div>
  

  <!-- heading section end -->


  <!-- content section start  -->

  <div class="container-fluid mt-5 mt-sm-2">
    <div class="row">
      <div class="col-md-6 col-lg-6 col-sm-6 col-12  m-sm-0 d-flex flex-row justify-content-center">
        <div class="mainContendiv d-flex justify-content-center">
          <img src="img/iPhone X.png" class="img-fluid" data-aos="zoom-out-down" data-aos-duration="1000"
            data-aos-offset="400">

        </div>

      </div>
      <div class="col-md-6 col-lg-6 col-sm-6 col-12   d-flex  align-items-center ">
        <div class="mainContendiv2 animate__animated animate__flipInX">
          <h1 class="contentHeading  ">A smart choice to the NextGen systems</h1>
          <p class="contentPara">Imdady is providing a cloud based on demand systems for your restaurant, retail stores & online ecommerce solution to increase your business by providing quick operations and Realtime data.</p>
          <ul class="contenUl">
            <li class="noneAOS" >Reliable</li>
            <li class="noneAOS" >Scalable</li>
            <li class="noneAOS" >Access anytime, anywhere</li>

          </ul>

        </div>


      </div>
    </div>
  </div>


  <div class="container-fluid mt-5 mt-none">
    <div class="row">
      <div class="col-12">
        <div class="container m-none ">
          <h1 class="benefit">Advantages of Working<br> with us</h1>


        </div>
      </div>
    </div>

    <div class="container mt-md-5 mt-xsm-4">
      <div class="row">
        <div class="col-md-6 col-lg-6 col-sm-12 col-12">
          <div class="row">
            <div class="col-3 col-sm-3 col-md-2  ">
              <img src="img/Feature Icon with circle.png" class="img-fluid ">
            </div>
            <div class="col-9 col-sm-9 col-md-10  ">
              <h1 class="benefitHeading">Time zones</h1>
              <p class="benefitPara">Our team always available to give prompt response for your queries.</p>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-6 col-sm-12 col-12 mt-xsm-3">
          <div class="row">
            <div class="col-3 col-sm-3 col-md-2">
              <img src="img/dot.png" class="img-fluid">
            </div>
            <div class="col-9 col-sm-9 col-md-10 ">
              <h1 class="benefitHeading">Full spectrum of services</h1>
              <p class="benefitPara">Team Imdady always available to provide best solution and proactive services to our customers.</p>
            </div>
          </div>
        </div>

      </div>

      <div class="row mt-md-5 mt-xsm-3">
        <div class="col-md-6 col-lg-6 col-sm-12 col-12">
          <div class="row">
            <div class="col-3 col-sm-3 col-md-2">
              <img src="img/3line.png" class="img-fluid">
            </div>
            <div class="col-9 col-sm-9 col-md-10 ">
              <h1 class="benefitHeading">Impossible? We’re on it</h1>
              <p class="benefitPara">We are always ready to sit across the table and comeup with the best solution for our customers requirement.</p>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-6 col-sm-12 col-12">
          <div class="row">
            <div class="col-3 col-sm-3 col-md-2">
              <img src="img/2box.png" class="img-fluid">
            </div>
            <div class="col-9 col-sm-9 col-md-10 ">
              <h1 class="benefitHeading">Flexible work terms</h1>
              <p class="benefitPara">Imdady have complete package of technical team members who works round the clock to ensure 100% uptime.</p>
            </div>
          </div>
        </div>

      </div>




      <div class="row mt-md-5 mt-xsm-4">
        <div class="col-12 col-md-6 col-lg-6">
          <h1 class="fashionHeading">Hassle free integrations.</h1>

        </div>
        <div class="col-12 col-md-6 col-lg-6">
          <p class="fashionPara">If you are running multiple stores and worry to manage all of them. <br> Imdady is developed for this to support and manage your business and sales just on single tap anytime, anywhere.</p>

        </div>
      </div>

      <div class="row mt-md-5 mt-xsm-4">
        <div class="col-12">
          <img src="img/Group 2.png" class="img-fluid">
        </div>
      </div>

      <div class="row mt-md-5 ">
        <div class="col-12 mt-xsm-3">
          <h1 class="getinHeading">Get In Touch With Us</h1>
        </div>
      </div>

      <div class="row mt-md-5 mt-sm-3  text-xsm-center">
        <div class="col-6 col-md-3 col-lg-3">
          <img src="img/Feature Icon with circle.png" class="img-fluid ">
          <h1 class="getInTochHeading">Where we are</h1>
          <p class="getInTochPara">Riyadh Olaya Dist, Computer Market, Olaya Street.</p>

        </div>

        <div class="col-6 col-md-3 col-lg-3">
          <img src="img/2box.png" class="img-fluid">
          <h1 class="getInTochHeading">Customer Care</h1>
          <p class="getInTochPara">Call us at: <a href="tel:+966535090666">+966535090666</a></p>

        </div>

        <div class="col-6 col-md-3 col-lg-3">
          <img src="img/3line.png" class="img-fluid">
          <h1 class="getInTochHeading">General Email</h1>
          <p class="getInTochPara">Write us at: <a href="mailto:info@futuregates.sa">info@futuregates.sa</a></p>

        </div>

        <div class="col-6 col-md-3 col-lg-3">
          <img src="img/dot.png" class="img-fluid">
          <h1 class="getInTochHeading">Work Hours</h1>
          <p class="getInTochPara">Mon. – Fri. 9AM – 2AM AST</p>

        </div>

      </div>



    </div>
  </div>

  <!-- content section end  -->



  <!-- footer start  -->
  <?php include('footer.php') ?>






  <!-- footer end  -->















  <!-- data AOS Animation start  -->
  <script src="js/AOS.js"></script>
  <script>
    AOS.init();
  </script>
  <!-- data AOS Animation start  -->



  <!-- bootstrap cdn start  -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
  <!-- bootstrap cdn end  -->
</body>

</html>